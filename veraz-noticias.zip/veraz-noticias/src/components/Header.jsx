// T-01: estructura básica de la página de noticias (terminada)
export default function Header() {
  return (
    <header className="encabezado">
      <h1>Veraz Noticias</h1>
      <p>Noticias locales verificadas y con contexto</p>
    </header>
  );
}
