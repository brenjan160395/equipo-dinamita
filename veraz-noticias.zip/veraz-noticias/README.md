# Veraz Noticias

Plataforma web de noticias locales verificadas y con contexto (Proyecto II, Universidad de Guadalajara).

## Estado del Sprint 1 (al 07/10/2026, día 3 de 15)

| Tarea | Descripción | Estado |
|---|---|---|
| T-01 | Estructura básica de la página de noticias | Completado |
| T-06 | Diseño del formulario de publicación | Completado |
| T-02 | Componente del listado de noticias | En progreso (50 %) |
| T-07 | Campos para registrar la noticia | En progreso (50 %) |
| T-04 | Integrar datos de prueba con las vistas | Bloqueado (IMP-001) |

Pendiente: T-03, T-05, T-08 a T-14.

## Cómo ejecutarlo

```bash
npm install
npm run dev
```

Después abre la dirección que muestre la terminal (normalmente http://localhost:5173).
